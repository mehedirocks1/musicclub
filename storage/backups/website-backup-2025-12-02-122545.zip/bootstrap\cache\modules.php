<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Members\\Providers\\MembersServiceProvider',
    1 => 'Modules\\Orders\\Providers\\OrdersServiceProvider',
    2 => 'Modules\\Packages\\Providers\\PackagesServiceProvider',
    3 => 'Modules\\Subscribers\\Providers\\SubscribersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Members\\Providers\\MembersServiceProvider',
    1 => 'Modules\\Orders\\Providers\\OrdersServiceProvider',
    2 => 'Modules\\Packages\\Providers\\PackagesServiceProvider',
    3 => 'Modules\\Subscribers\\Providers\\SubscribersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);