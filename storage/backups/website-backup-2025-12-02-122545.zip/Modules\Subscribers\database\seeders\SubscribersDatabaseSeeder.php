<?php

namespace Modules\Subscribers\Database\Seeders;

use Illuminate\Database\Seeder;

class SubscribersDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
