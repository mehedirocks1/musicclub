<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\MemberPanelProvider::class,
    App\Providers\VoltServiceProvider::class,
    Raziul\Sslcommerz\SslcommerzServiceProvider::class,
];
