<?php

namespace App\Filament\Resources\Branches\Pages;

use App\Filament\Resources\Branches\BranchesResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBranches extends CreateRecord
{
    protected static string $resource = BranchesResource::class;
}
