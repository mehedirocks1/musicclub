<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;
use BackedEnum; 

class Backup extends Page
{
    use \Livewire\WithFileUploads;

    // Page config
    protected static ?string $navigationLabel = 'Backup';
    protected static ?string $title = 'Backup';
    protected static BackedEnum|string|null $navigationIcon = 'heroicon-o-cloud-arrow-down';
    protected string $view = 'filament.pages.backup';

    // Progress properties
    public int $websiteProgress = 0;
    public int $databaseProgress = 0;
    public string $statusMessage = '';

    /**
     * Backup website files
     */
    public function backupWebsite()
    {
        // 1. Prevent Timeout (Important for large backups)
        set_time_limit(0); 
        ini_set('memory_limit', '-1');

        $this->websiteProgress = 0;
        $this->statusMessage = 'Starting website backup...';

        $rootPath = base_path(); 
        $backupDir = storage_path('backups');

        if (!file_exists($backupDir)) {
            mkdir($backupDir, 0755, true);
        }

        $zipFile = $backupDir . '/website-backup-' . date('Y-m-d-His') . '.zip';

        $zip = new \ZipArchive();
        if ($zip->open($zipFile, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== TRUE) {
            $this->statusMessage = 'Failed to create ZIP file.';
            Notification::make()->title('Backup Failed')->danger()->send();
            return;
        }

        // 2. Setup Iterator
        $files = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($rootPath, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );

        // Warning: iterator_count can be slow on large projects
        // We use a rough estimate or just count if necessary.
        // For performance, you might remove this and just show "Processing..." 
        // But we will keep it to fix your logic.
        $totalFiles = iterator_count($files); 
        $files->rewind(); 

        $counter = 0;
        
        // 3. Define folders to IGNORE (Crucial for performance)
        $ignoredFolders = [
            'vendor', 
            'node_modules', 
            '.git', 
            'storage/backups' // Don't backup the backup folder itself!
        ];

        foreach ($files as $file) {
            if (!$file->isFile()) continue;

            $filePath = $file->getRealPath();
            $relativePath = ltrim(str_replace($rootPath, '', $filePath), DIRECTORY_SEPARATOR);
            $relativePathForwardSlash = str_replace('\\', '/', $relativePath); // Normalize for checking

            // 4. Skip Ignored Folders
            $shouldSkip = false;
            foreach ($ignoredFolders as $ignore) {
                if (str_starts_with($relativePathForwardSlash, $ignore)) {
                    $shouldSkip = true;
                    break;
                }
            }
            if ($shouldSkip) {
                // We still increment counter so progress bar finishes
                $counter++;
                continue; 
            }

            $zip->addFile($filePath, $relativePath);

            $counter++;
            
            // 5. Update UI (Throttle updates to every 50 files to save performance)
            if ($counter % 50 === 0 || $counter === $totalFiles) {
                $this->websiteProgress = intval(($counter / $totalFiles) * 100);
                $this->statusMessage = "Archiving: " . basename($relativePath);
                
                // ✅ FIX: Use dispatch() instead of emitSelf()
                $this->dispatch('refreshProgress'); 
            }
        }

        $zip->close();

        $this->websiteProgress = 100;
        $this->statusMessage = 'Website backup completed!';
        
        Notification::make()
            ->title('Website backup completed')
            ->success()
            ->send();
    }

    /**
     * Backup database (simulation)
     */
    public function backupDatabase()
    {
        $this->databaseProgress = 0;
        $this->statusMessage = 'Starting database backup...';

        $steps = [
            'Dumping database tables...',
            'Compressing dump...',
            'Saving backup file...',
        ];

        $total = count($steps);
        foreach ($steps as $index => $step) {
            $this->databaseProgress = intval((($index + 1) / $total) * 100);
            $this->statusMessage = $step;

            // ✅ FIX: Use dispatch() instead of emitSelf()
            $this->dispatch('refreshProgress');
            
            sleep(1); 
        }

        $this->databaseProgress = 100;
        $this->statusMessage = 'Database backup completed!';
        
        Notification::make()
            ->title('Database backup completed')
            ->success()
            ->send();
    }
}