<?php

return [
    'name' => 'Subscribers',
];
