<?php

namespace App\Filament\Resources\Branches\Schemas;

use Filament\Schemas\Schema;

class BranchesInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
