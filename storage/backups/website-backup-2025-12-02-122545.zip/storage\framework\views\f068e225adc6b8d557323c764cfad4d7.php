<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal9b945b32438afb742355861768089b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b945b32438afb742355861768089b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.card','data' => ['class' => 'p-4 w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-4 w-full']); ?>
        <div class="flex flex-wrap items-center justify-start gap-6 w-full">
            
            <div class="flex items-center space-x-2 bg-blue-50 rounded-lg px-4 py-2 flex-1 min-w-[200px]">
                <span class="text-2xl text-blue-600">👤</span>
                <span class="font-semibold text-blue-700">Welcome: <?php echo e($userName); ?></span>
            </div>

            
            <div class="flex items-center space-x-2 bg-green-50 rounded-lg px-4 py-2 flex-1 min-w-[200px]">
                <span class="text-2xl text-green-600">📅</span>
                <span class="font-semibold text-green-700">Today: <?php echo e($currentDate); ?></span>
            </div>

            
            <div class="flex items-center space-x-2 bg-yellow-50 rounded-lg px-4 py-2 flex-1 min-w-[200px]">
                <span class="text-2xl text-yellow-600">⏰</span>
                <span class="font-semibold text-yellow-700">Time (GMT+6): <?php echo e($currentTime); ?></span>
            </div>

            
            <div class="flex items-center space-x-2 bg-indigo-50 rounded-lg px-4 py-2 flex-1 min-w-[200px]">
                <span class="text-2xl text-indigo-600">💻</span>
                <span class="font-semibold text-indigo-700">PHP Version: <?php echo e($phpVersion); ?></span>
            </div>

            
            <div class="flex items-center space-x-2 bg-pink-50 rounded-lg px-4 py-2 flex-1 min-w-[200px]">
                <span class="text-2xl text-pink-600">🚀</span>
                <span class="font-semibold text-pink-700">Laravel Version: <?php echo e($laravelVersion); ?></span>
            </div>

            
            <div class="flex items-center space-x-2 bg-gray-50 rounded-lg px-4 py-2 flex-1 min-w-[200px]">
                <span class="text-2xl text-gray-600">🖥️</span>
                <span class="font-semibold text-gray-700">Server OS: <?php echo e($serverOs); ?></span>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b945b32438afb742355861768089b04)): ?>
<?php $attributes = $__attributesOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__attributesOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b945b32438afb742355861768089b04)): ?>
<?php $component = $__componentOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__componentOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\musicclub\resources\views/filament/widgets/a-system-info-widget.blade.php ENDPATH**/ ?>