<x-orders::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('orders.name') !!}</p>
</x-orders::layouts.master>
