<?php

namespace App\Filament\Resources\Subscribers\Schemas;

use Filament\Schemas\Schema;

class SubscriberInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
