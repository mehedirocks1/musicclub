<x-subscribers::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('subscribers.name') !!}</p>
</x-subscribers::layouts.master>
