<?php

namespace Modules\Members\Database\Seeders;

use Illuminate\Database\Seeder;

class MembersDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
