<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div 
        x-data="{ 
            isSending: false,
            progress: 0, 
            total: 0, 
            sentCount: 0,
            failedCount: 0,
            
            async startSending() {
                this.isSending = true;
                this.progress = 0;
                this.sentCount = 0;
                this.failedCount = 0;

                // 1. Ask PHP to prepare the list
                const result = await $wire.prepareNumbers();
                
                if (!result || result.count === 0) {
                    this.isSending = false;
                    return;
                }

                this.total = result.count;
                
                // 2. Client-side loop to trigger PHP calls one by one
                for (let i = 0; i < this.total; i++) {
                    let status = await $wire.sendSingleSms(i);
                    
                    if(status === 'sent') this.sentCount++;
                    else this.failedCount++;

                    this.progress = Math.round(((i + 1) / this.total) * 100);
                }

                // 3. Done
                this.isSending = false;
                $wire.sendingComplete();
            }
        }"
    >

        <div class="space-y-4" :class="{ 'opacity-50 pointer-events-none': isSending }">
            <?php echo e($this->form); ?>

        
            <div class="flex justify-end">
                <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['size' => 'lg','icon' => 'heroicon-m-paper-airplane','@click' => 'startSending','wire:loading.attr' => 'disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'lg','icon' => 'heroicon-m-paper-airplane','@click' => 'startSending','wire:loading.attr' => 'disabled']); ?>
                    Start Sending
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
            </div>
        </div>

        
        <div x-show="isSending || progress > 0" x-transition class="mt-6 p-4 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700">
            <div class="flex justify-between mb-2 text-sm font-medium">
                <span>Progress</span>
                <span x-text="progress + '%'"></span>
            </div>
            <div class="w-full bg-gray-200 dark:bg-gray-700 h-4 rounded-full overflow-hidden">
                <div class="bg-primary-600 h-4 transition-all duration-300" :style="'width: ' + progress + '%'"></div>
            </div>
            <div class="grid grid-cols-3 gap-4 mt-4 text-center">
                <div class="font-bold text-gray-700 dark:text-gray-200">Total: <span x-text="total"></span></div>
                <div class="font-bold text-green-600">Sent: <span x-text="sentCount"></span></div>
                <div class="font-bold text-red-600">Failed: <span x-text="failedCount"></span></div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\musicclub\resources\views/filament/pages/bulk-sms-sender.blade.php ENDPATH**/ ?>